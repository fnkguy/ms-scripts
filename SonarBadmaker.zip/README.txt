-- FOR INTERNAL SUPPORT USE BY MICROSOFT ONLY --

# MICROSOFT-INTERNAL
# Microsoft internal use only. Not intended for customers.

You can use an internal (support-only) tool to create a test file, and then send/upload the file in your tenant. Use this syntax at a command prompt to create your test file: SonarBadMaker.exe <output path/file>
You cannot provide SONARBadMaker to customers, or even people outside support. This is for internal testing. If you really need to provide the customer with a test file for ATP Safe Attachments, generate a new file with SONARBadMaker, zip up the generated file in a password-protected zip and upload it to their workspace.

Note that you can only typically use a file once to force ATP SA detonation. This is why:
1. You send your new SONARBadMaker-generated test file through EOP.
2. ATP SA detonates and detects the file as malware. At this point, a SONAR signature is created in ATP SA.
3. Within a short time (could be an hour or two), the SONAR signature is replicated back into the anti-malware component of EOP.
4. When you try to resend the same test file through again, the anti-malware component will detect the malware first (as 'Malicious Payload'), rather than ATP SA.